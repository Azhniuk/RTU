#include "Cat.h"
#include <string> 
#define strcasecmp _stricmp

void Cat::send_to(ostream& os) const
{
    Item::send_to(os);
    os << csv_delimiter << _name <<
        csv_delimiter << _color ;
}

void Cat::recv_from(istream& is)
{
    if (is)
        (is >> _name).ignore();

    if (is)
        (is >> _color).ignore();
}






