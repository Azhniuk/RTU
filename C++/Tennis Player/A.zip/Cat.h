#pragma once
#ifndef CAT
#define CAT
#include <string>
#include <iostream>
#include "Item.h"
#include "CatSpec.h"
#include <memory>
using namespace std;


class Cat : public Item
{
public:
	Cat() = default;

	Cat(int id, string name , int color, shared_ptr<const CatSpec> spec)
		: Item(id, spec)
		, _name{ name }
		, _color{ color }
	{ }
	
	string get_name() const { return _name; }
	int get_color() const { return _color; }

	void send_to(ostream& os) const override;
	void recv_from(istream& is);


private:
	int _color;
	string _name;
};

#endif