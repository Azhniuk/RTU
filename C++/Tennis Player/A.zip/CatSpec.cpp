﻿#include "CatSpec.h"
#include <string> 
#define strcasecmp _stricmp

#ifdef _MSC_VER // Visual C++ ?
#define strcasecmp _stricmp // then use the function _stricmp() 
#else
#include <strings.h> // for strcasecmp() function in POSIX C++
#endif

istream& operator>>(istream& is, CatSpec& item)
{
    item.recv_from(is);
    return is;
}
void CatSpec::send_to(ostream& os) const {

    os << _height << csv_delimiter
        << _weight << csv_delimiter
        << _says ;
}
void CatSpec::recv_from(istream& is)
{
    if (is)
        (is >> _height).ignore();
    if (is)
        (is >> _weight).ignore();

    if (is)
        (is >> _says).ignore();
}


bool CatSpec::matches(const ItemSpec& itemSpec) const
{
    if (this == &itemSpec)
        return true;

    bool result{ true };

    auto temp{ dynamic_cast<const CatSpec*>(&itemSpec) };
    if (nullptr == temp)
        return false;

    const CatSpec& otherSpec{ *temp };


    if (result && 0 != otherSpec._height &&
        _height != otherSpec._height)
    {
        result = false;
    }

    if (result && 0 != otherSpec._weight &&
        _weight != otherSpec._weight)
    {
        result = false;
    }

    if ( otherSpec.get_says() != this->_says)
        result = false;


    return result;
}





