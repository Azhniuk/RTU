#pragma once
#ifndef Cat_SPEC
#define Cat_SPEC

#include <cstddef>
#include <memory>
#include <iostream>
#include "ItemSpec.h"

using namespace std;

class CatSpec : public ItemSpec
{
public:
    CatSpec() = default;

    CatSpec(double height, double weight, string says)
        : _height{ height }, _weight{ weight }, _says{ says }
    { }

    string get_says() const { return _says; }
    double get_height() const { return _height; }
    double get_weight() const { return _weight; }

    void send_to(ostream& os) const override;
    void recv_from(istream& is);// override
    bool matches(const ItemSpec& itemSpec) const override;


private:
    double _height;
    double _weight;
    string _says;
};


#endif