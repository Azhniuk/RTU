#include "Item.h"

void Item::send_to(std::ostream& os) const
{
    os << _id;

    if (_spec)
    {
        _spec->send_to(os);
    }
}

std::ostream& operator<<(std::ostream& os, const Item& item)
{
    item.send_to(os);
    return os;
}