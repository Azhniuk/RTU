#ifndef LOG
#define LOG

#include "ItemSpec.h"
#include "Item.h"
#include <memory>
#include <stdexcept>
#include <exception>
#include <string>
using namespace std;


class Log
{
public:
    Log(): _count{0} {}
    size_t get_count() const { return _count; }

    const Item& operator[](size_t i) const { return get_item(i); }

    const Item& get_item(size_t i) const
    {
        if (i < _count) return *_items[i];

        throw std::out_of_range("Invalid index value.");
    }

    void add_item(std::shared_ptr<Item> newItem);

    const Item& find_item(const ItemSpec& otherSpec) const;
    
   /* void save(const string& csv_file_name) const;
    void load(const string& csv_file_name);*/

private:
    static const size_t MAX_SIZE{ 10 };
    shared_ptr<Item> _items[Log::MAX_SIZE];

    size_t _count;
};


#endif
