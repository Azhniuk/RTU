﻿#include "Player.h"
#include <string> 
#define strcasecmp _stricmp

void Player::send_to(ostream& os) const
{
    Item::send_to(os); 
    os << csv_delimiter << _comment <<
        csv_delimiter << _nick;
}

void Player::recv_from(istream& is)
{
    if (is)
        (is >> _comment).ignore();

    if (is)
        (is >> _nick).ignore();
}




















