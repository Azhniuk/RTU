#pragma once
#ifndef PLAYER
#define PLAYER
#include <string>
#include <iostream>
#include "Item.h"
#include "PlayerSpec.h"
#include <memory>
using namespace std;


class Player : public Item
{
public:	
	Player() = default;

	Player(int id, string comment, string nick, shared_ptr<const PlayerSpec> spec)
		: Item(id, spec)
		, _comment{ comment }
		, _nick{ nick }
	{ }
	
	string get_comment() const { return _comment; }
	string get_nick() const { return _nick; }

	void send_to(ostream& os) const override;
	void recv_from(istream& is);


private:
	string _nick;
	string _comment;
};

#endif