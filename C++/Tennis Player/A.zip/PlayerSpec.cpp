﻿#include "PlayerSpec.h"
#include <string> 
#define strcasecmp _stricmp

#ifdef _MSC_VER // Visual C++ ?
#define strcasecmp _stricmp // then use the function _stricmp() 
#else
#include <strings.h> // for strcasecmp() function in POSIX C++
#endif


ostream& operator<<( ostream& os, PlayerSpec::Experience experiences)
{
    return os << PlayerSpec::Experience_str[static_cast<size_t>(experiences)];
}

ostream& operator<<( ostream& os, PlayerSpec::Sport sports)
{
    return os << PlayerSpec::Sport_str[static_cast<size_t>(sports)];
}

istream& operator>>(istream& is, PlayerSpec::Experience & experiences)
{
    if (is)
    {
        string tmp;
        getline(is, tmp, csv_delimiter);
        if (is)
        {
            bool found{ false };

            for (size_t i{ 0 }; i < sizeof(PlayerSpec::Experience_str) / sizeof(PlayerSpec::Experience_str[0]); i++)
            {
                if (tmp.length() == PlayerSpec::Experience_str[i].length()
                    && 0 == strcasecmp(tmp.c_str(),  string(PlayerSpec::Experience_str[i]).c_str())) // case insensitive comparison
                {
                    experiences = static_cast<PlayerSpec::Experience>(i);
                    found = true;
                    break;
                }
            }

            if (!found)
                experiences = PlayerSpec::Experience::ANY;
        }
    }
    return is;
}



istream& operator>>(istream& is, PlayerSpec::Sport sports)
{
    if (is)
    {
        string tmp;
        getline(is, tmp, csv_delimiter);
        if (is)
        {
            bool found{ false };

            for (size_t i{ 0 }; i < sizeof(PlayerSpec::Sport_str) / sizeof(PlayerSpec::Sport_str[0]); i++)
            {
                if (tmp.length() == PlayerSpec::Sport_str[i].length()
                    && 0 == strcasecmp(tmp.c_str(),  string(PlayerSpec::Sport_str[i]).c_str())) 
                {
                    sports = static_cast<PlayerSpec::Sport>(i);
                    found = true;
                    break;
                }
            }

            if (!found)
                sports = PlayerSpec::Sport::ANY;
        }
    }
    return is;
}



istream& operator>>(istream& is, PlayerSpec& item)
{
    item.recv_from(is);
    return is;
}


void PlayerSpec::send_to(ostream& os) const {

    os << _height << csv_delimiter
        << _weight << csv_delimiter
        << _experiences << csv_delimiter
        << _sports;
}



void PlayerSpec::recv_from(istream& is)
{
    if (is)
        (is >> _height).ignore();

    if (is)
        (is >> _weight).ignore();

    if (is)
        is >> _experiences;

    if (is)
        is >> _sports;

}


bool PlayerSpec::matches(const ItemSpec& itemSpec) const
{
    if (this == &itemSpec)
        return true; 

    bool result{ true };

    auto temp{ dynamic_cast<const PlayerSpec*>(&itemSpec) };
    if (nullptr == temp)
        return false;

    // cast to reference type for actual comparison of properties
    const PlayerSpec& otherSpec{ *temp };


    if (result && 0 != otherSpec._height &&
        _height != otherSpec._height)
    {
        result = false;
    }

    if (result && 0 != otherSpec._weight &&
        _weight != otherSpec._weight)
    {
        result = false;
    }

    if (result && otherSpec._experiences != Experience::ANY &&
        _experiences != otherSpec._experiences)
    {
        result = false;
    }

    if (result && otherSpec._sports != Sport::ANY &&
        _sports != otherSpec._sports)
    {
        result = false;
    }

    return result;
}





