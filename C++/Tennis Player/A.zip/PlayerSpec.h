#pragma once
#ifndef PLAYER_SPEC
#define PLAYER_SPEC

#include <cstddef>
#include <memory>
#include <iostream>
#include "ItemSpec.h"

using namespace std;

class PlayerSpec : public ItemSpec
{
public:
    
    enum class Experience { ANY, zero, two, three, five, ten };
    static constexpr string_view Experience_str[]{ "Any", "0", "2", "3", "5", "10" };

    enum class Sport { ANY, swimming, running, box, skiing };
    static constexpr string_view Sport_str[]{ "Any", "swimming", "running", "box", "skiing" };

    PlayerSpec()
        : _height{ 0.0 }, _weight{ 0.0 }, _experiences{ Experience::ANY }, _sports{ Sport::ANY }
    { }

    PlayerSpec(double height, double weight, Experience experiences, Sport sports)
        : _height{ height }, _weight{ weight }, _experiences{ experiences }, _sports{ sports }
    { }

    Experience get_experience() const { return _experiences; }
    Sport get_sport() const { return _sports; }
    double get_height() const { return _height; }
    double get_weight() const { return _weight; }

    void send_to(ostream& os) const override;
    void recv_from(istream& is);// override
    bool matches(const ItemSpec& itemSpec) const override;


private:
    double _height;
    double _weight;
    Experience _experiences;
    Sport _sports;
};


ostream& operator<<(ostream& os, PlayerSpec::Experience experiences);

ostream& operator<<(ostream& os, PlayerSpec::Sport sports);
istream& operator>>(istream& is, PlayerSpec::Sport sports);


#endif