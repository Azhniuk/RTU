#include <iostream>
#include "Player.h"
#include "Log.h"
#include "Cat.h"
#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

void show(const Item& item)
{
    cout << item << "\n";
}

Player max_weight(const Log& log)
{
    int max_pos{ -1 };
    float max_weight = 0;

    for (auto i{ 0 }; i < log.get_count(); i++)
    {
        auto ptr = dynamic_cast<const PlayerSpec*>(&*log[i].get_spec());
        if (nullptr == ptr) {
            continue;
        }
        else
        {
            if (ptr->get_weight() > max_weight)
            {
                max_weight = ptr->get_weight();
                max_pos = i;
            }
        }
    }
    if (max_pos >= 0)
    {
        auto item_p{ &log[max_pos] };
        auto bicycle_p{ static_cast<const Player*>(item_p) };
        return *bicycle_p;
    }
    else
    {
        return Player{}; 
    }
}


int main()
{
    Log log;
    auto spec_Ihor{ make_shared<PlayerSpec>(210.9, 100, PlayerSpec::Experience::ten, PlayerSpec::Sport::running) };
    auto b1{make_shared<Player>(1, "good player", "Dita", spec_Ihor)};
    log.add_item(b1);

    auto b2{ make_shared<Player>(2, "horrible person", "Bars", make_shared<PlayerSpec>(167.5, 80.7, PlayerSpec::Experience::five, PlayerSpec::Sport::box)) };
    log.add_item(b2);

    auto spec_cat{ make_shared<PlayerSpec>(60.7, 8, PlayerSpec::Experience::five, PlayerSpec::Sport::skiing) };
    log.add_item(make_shared<Player>(3, "not a cat", "Ihor", spec_cat));
    log.add_item(make_shared<Player>(4, "a car", "Keks", spec_cat));

    show(log.find_item(PlayerSpec{ 60.7, 8, PlayerSpec::Experience::ANY,  PlayerSpec::Sport::ANY}));
    // test with another query values
    show(log.find_item(*spec_cat));
    show(log.find_item(PlayerSpec{}));

    //testing for non-matching criterion
    show(log.find_item(PlayerSpec{ 4454, 204, PlayerSpec::Experience::ANY,  PlayerSpec::Sport::skiing }));

    // store another type of abstraction
    auto c1{ make_shared<Cat>(5, "Boberokit", 3, make_shared<CatSpec>(3.22, 4.2, "O"))};
    log.add_item(c1); 
    show(log.find_item(CatSpec{ 0, 4.2, "O" }));
 
    show(max_weight(log));
    return 0;
}





