#include "Player.h"

Player::Player(Player::Nick nick, bool play, const PlayerSpec& spec)
{	
	_nick = nick;
	_play = play;
	_spec = spec;
	}


//ctrl+k+c   ctrl+k+u -  multiple comment