#include "PlayerSpec.h"

//double height, double weight, Player::Experience experiences
//_height = height;
//_weight = weight;
//_experiences = experiences;



